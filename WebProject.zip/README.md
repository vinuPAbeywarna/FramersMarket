# INSTRCUTIONS FOR RUNNING THE PROJECT
create a mysql database named "farmersmarket". then,
1. composer install
2. php artisan migrate
3. php artisan db:seed

## Admin Logins
NIC = 1234
password = admin


