# INSTRCUTIONS FOR RUNNING THE PROJECT
create the .env file then.
1. composer install
2. php artisan migrate

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
