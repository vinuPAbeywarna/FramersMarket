<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>FarmersMarket</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../assets/fonts/fontawesome5-overrides.min.css">
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA9vA47OJhiGUHAMljNXKYS_tV0863vUcY"></script>
    <script src="https://unpkg.com/location-picker/dist/location-picker.min.js"></script>
</head>


<body id="page-top">
<div id="wrapper">
    <?php echo $__env->make('SideBar.SideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex flex-column" id="content-wrapper">
        <div id="content">
            <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle mr-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                    <form class="user" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="input-group"><input class="bg-light form-control border-0 small" type="text" placeholder="Search for ...">
                            <div class="input-group-append"><button class="btn btn-primary py-0" type="button"><i class="fas fa-search"></i></button></div>
                        </div>
                    </form>
                </div>
            </nav>
            <div class="container-fluid">
                <div class="card shadow">
                    <div class="card-header py-3">
                        <p class="text-primary m-0 font-weight-bold">Submit Report</p>
                    </div>
                    <div class="card-body">
                        <form method="post" action="/updatereportsave">
                            <?php echo csrf_field(); ?>
                            <div class="form-group"><select class="form-control" name="HarvestType" required="">
                                    <optgroup label="Select Harvest Type">
                                        <option <?php if($Report->HarvestType == 'Vegetables'): ?> selected <?php endif; ?> value="Vegetables">Vegetables</option>
                                        <option <?php if($Report->HarvestType == 'Fruits'): ?> selected <?php endif; ?> value="Fruits">Fruits</option>
                                        <option <?php if($Report->HarvestType == 'Nuts'): ?> selected <?php endif; ?> value="Nuts">Nuts</option>
                                        <option <?php if($Report->HarvestType == 'Grain'): ?> selected <?php endif; ?> value="Grain">Grain</option>
                                    </optgroup>
                                </select></div>
                            <div class="form-group"><input class="form-control" value="<?php echo e($Report->Amount); ?>" min="1" step="any" type="number" name="Amount" required="" inputmode="numeric" placeholder="Total Amount (kg)"></div>
                            <div class="form-group"><input class="form-control" value="<?php echo e($Report->WAmount); ?>" min="0" step="any" type="number" name="WAmount" required="" inputmode="numeric" placeholder="Wastage Amount (kg)"></div>
                            <div class="form-group"><label>Location</label>
                                <div style="height: 256px; width: 100%" id="map"></div>
                            </div>
                            <div class="form-group"><label>Selected Location</label>
                                <label>
                                    Lat :<input value="<?php echo e($Report->Lat); ?>" name="Lat" type="number" step="any" class="form-control" id="maplat">
                                </label>
                                <label>
                                    Lang : <input value="<?php echo e($Report->Lang); ?>" name="Lang" type="number" step="any" class="form-control" id="maplang">
                                </label>
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="District" required="">
                                    <optgroup label="Select Your District">
                                        <option <?php if($Report->District=='Ampara'): ?> selected <?php endif; ?> value="Ampara">Ampara</option>
                                        <option <?php if($Report->District=='Anuradhapura'): ?> selected <?php endif; ?> value="Anuradhapura">Anuradhapura</option>
                                        <option <?php if($Report->District=='Badulla'): ?> selected <?php endif; ?> value="Badulla">Badulla</option>
                                        <option <?php if($Report->District=='Batticaloa'): ?> selected <?php endif; ?> value="Batticaloa">Batticaloa</option>
                                        <option <?php if($Report->District=='Mannar'): ?> selected <?php endif; ?> value="Mannar">Batticaloa</option>

                                        <option <?php if($Report->District=='Colombo'): ?> selected <?php endif; ?> value="Colombo">Colombo</option>
                                        <option <?php if($Report->District=='Galle'): ?> selected <?php endif; ?> value="Galle">Galle</option>
                                        <option <?php if($Report->District=='Gampaha'): ?> selected <?php endif; ?> value="Gampaha">Gampaha</option>
                                        <option <?php if($Report->District=='Hambanthota'): ?> selected <?php endif; ?> value="Hambanthota">Hambanthota</option>
                                        <option <?php if($Report->District=='Jaffna'): ?> selected <?php endif; ?> value="Jaffna">Jaffna</option>

                                        <option <?php if($Report->District=='Kaluthara'): ?> selected <?php endif; ?> value="Kaluthara">Kaluthara</option>
                                        <option <?php if($Report->District=='Kandy'): ?> selected <?php endif; ?> value="Kandy">Kandy</option>
                                        <option <?php if($Report->District=='Kegalle'): ?> selected <?php endif; ?> value="Kegalle">Kegalle</option>
                                        <option <?php if($Report->District=='Kilinochchi'): ?> selected <?php endif; ?> value="Kilinochchi">Kilinochchi</option>
                                        <option <?php if($Report->District=='kurunegala'): ?> selected <?php endif; ?> value="kurunegala">kurunegala</option>

                                        <option <?php if($Report->District=='Matara'): ?> selected <?php endif; ?> value="Matara">Matara</option>
                                        <option <?php if($Report->District=='Matale'): ?> selected <?php endif; ?> value="Matale">Matale</option>
                                        <option <?php if($Report->District=='Monaragala'): ?> selected <?php endif; ?> value="Monaragala">Monaragala</option>
                                        <option <?php if($Report->District=='Mulathiv'): ?> selected <?php endif; ?> value="Mulathiv">Mulathiv</option>
                                        <option <?php if($Report->District=='Nuwara Eliya'): ?> selected <?php endif; ?> value="Nuwara Eliya">Nuwara Eliya</option>

                                        <option <?php if($Report->District=='Putthalama '): ?> selected <?php endif; ?> value="Putthalama">Putthalama</option>
                                        <option <?php if($Report->District=='Rathnapura '): ?> selected <?php endif; ?> value="Rathnapura">Rathnapura</option>
                                        <option <?php if($Report->District=='Trincomalee '): ?> selected <?php endif; ?> value="Trincomalee">Trincomalee</option>
                                        <option <?php if($Report->District=='Vavniya '): ?> selected <?php endif; ?> value="Vavniya">Vavniya</option>
                                        <option <?php if($Report->District=='Matale '): ?> selected <?php endif; ?> value="Matale">Matale</option>
                                    </optgroup>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="exampleForControlfile1">Select Product Image</label>
                                <input type="file" name="PImage" class="form-control" id="exampleForControlfile1">
                            </div>

                            <div class="form-group"><textarea value="<?php echo e($Report->Description); ?>" class="form-control" name="Description" placeholder="Description" required=""></textarea></div>
                            <button class="btn btn-primary btn-block btn-lg" type="submit">Save Report</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
<script src="../../assets/js/script.min.js"></script>
<script>
    // Get element references
    //let confirmBtn = document.getElementById('confirmPosition');
    //let onClickPositionView = document.getElementById('onClickPositionView');
    let locLat = document.getElementById('maplat');
    let locLang = document.getElementById('maplang');

    // Initialize locationPicker plugin
    let lp = new locationPicker('map', {
        setCurrentPosition: true,
    }, {
        zoom: 11
    });




    // Listen to map idle event, listening to idle event more accurate than listening to ondrag event
    google.maps.event.addListener(lp.map, 'idle', function (event) {
        // Get current location and show it in HTML
        let location = lp.getMarkerPosition();
        console.log(lp);
        locLat.value = location.lat;
        locLang.value = location.lng;
    });

    //confirmBtn.onclick = function () {
    // Get current location and show it in HTML
    // let location = lp.getMarkerPosition();
    // onClickPositionView.innerHTML = 'The chosen location is ' + location.lat + ',' + location.lng;
    // };
</script>
</body>

</html>

<?php /**PATH C:\Projects\Web\WebProject\resources\views/UpdateReport.blade.php ENDPATH**/ ?>