<?php echo $__env->make('Common.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body id="page-top">
<div id="wrapper">
    <?php echo $__env->make('SideBar.SideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex flex-column" id="content-wrapper">
        <div id="content">
            <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                <div class="container-fluid">
                    <button class="btn btn-link d-md-none rounded-circle mr-3" id="sidebarToggleTop" type="button"><i
                            class="fas fa-bars"></i></button>
                    <form
                        class="form-inline d-none d-sm-inline-block mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group"><input class="bg-light form-control border-0 small" type="text"
                                                        placeholder="Search for ...">
                            <div class="input-group-append">
                                <button class="btn btn-primary py-0" type="button"><i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </nav>
            <div class="container-fluid">
                <?php
                    $userType = \Illuminate\Support\Facades\Session::get('UserType');
                ?>
                <h3 class="text-dark mb-4">Profile | <?php echo e($userType); ?></h3>
                <div class="row mb-3">
                    <div class="col-lg-4">
                        <div class="card mb-3">


                            <div class="card-body text-center shadow">
                                <?php
                                $User = \App\Models\UserModel::where('NIC','=', \Illuminate\Support\Facades\Session::get('NIC'))->first();
                                ?>

                                    <img class="rounded-circle mb-3 mt-4" src="/storage/<?php echo e($User->Photo); ?>" width="160"
                                         height="160">



                                <div class="mb-3">
                                    <form enctype="multipart/form-data" method="POST" action="/photoUpload">
                                        <?php echo csrf_field(); ?>

                                        <div class="row no-gutters">
                                            <div class="col">
                                                <input type="file" class="form-control-file" name="Photo">
                                            </div>
                                            <div class="col">
                                                <input type="submit" class="btn btn-primary btn-sm" value="Change Photo">
                                            </div>
                                        </div>


                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="row">
                            <div class="col">
                                <div class="card shadow mb-3">
                                    <div class="card-header py-3">
                                        <p class="text-primary m-0 font-weight-bold">User Settings</p>
                                    </div>
                                    <div class="card-body">
                                        <?php
                                            $User = App\Models\UserModel::where('NIC','=',\Illuminate\Support\Facades\Session::get('NIC'))->get()->first();
                                        ?>
                                        <form method="post" action="/updateUser">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-row">
                                                <div class="col">
                                                    <div class="form-group"><label for="username"><strong>Full</strong>&nbsp;Name</label><input
                                                            class="form-control" type="text" value="<?php echo e($User->Name); ?>"
                                                            name="Name"></div>
                                                </div>
                                                <div class="col">
                                                    <div class="form-group"><label
                                                            for="email"><strong>NIC</strong></label><input
                                                            class="form-control" type="text" value="<?php echo e($User->NIC); ?>"
                                                            name="NIC"></div>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="col">
                                                    <div class="form-group"><label
                                                            for="first_name"><strong>Phone</strong></label><input
                                                            class="form-control" type="text" value="<?php echo e($User->Phone); ?>"
                                                            name="Phone"></div>
                                                </div>
                                                <div class="col">
                                                    <div class="form-group"><label
                                                            for="last_name"><strong>Email</strong><br></label><input
                                                            class="form-control" type="text" value="<?php echo e($User->Email); ?>"
                                                            name="Email"></div>
                                                </div>
                                            </div>
                                            <div class="form-group"><label
                                                    for="first_name"><strong>Address</strong></label><input
                                                    class="form-control" type="text" value="<?php echo e($User->Address); ?>"
                                                    name="Address"></div>
                                            <div class="form-group">
                                                <button class="btn btn-primary btn-sm" type="submit">Save Settings
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(Session('UserType') == 'Farmer'): ?>
                    <div class="card shadow mb-5">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 font-weight-bold">Reports</p>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th>Report Type / Date</th>
                                                <th>Actions</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                                $Reports = \App\Models\ReportModel::where('FarmerNIC','=', Session('NIC'))->get();
                                            ?>
                                            <?php $__currentLoopData = $Reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($Report->HarvestType); ?> | <?php echo e($Report->updated_at); ?></td>
                                                    <td>

                                                        <div class="btn-group btn-group-sm" role="group">

                                                            <form method="get" action="/updatereport/<?php echo e($Report->id); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <input hidden name="id" value="<?php echo e($Report->id); ?>| <?php echo e($Report->updated_at); ?>">
                                                                <input class="btn btn-primary" type="submit" value="Edit">
                                                            </form>

                                                            <form method="post" action="/deletereport">
                                                                <?php echo csrf_field(); ?>
                                                                <input hidden name="id" value="<?php echo e($Report->id); ?>">
                                                            <input class="btn btn-danger" type="submit" value="Delete">
                                                            </form>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
    <a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
</div>
<?php echo $__env->make('Common.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Projects\Web\WebProject\resources\views/Profile.blade.php ENDPATH**/ ?>